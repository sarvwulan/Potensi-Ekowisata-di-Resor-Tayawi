var json_TitikPotensiEkowisata_3 = {
"type": "FeatureCollection",
"name": "TitikPotensiEkowisata_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Objective": "Sungai Bay Roray", "X": 353600.21198000002, "Y": 57287.835, "Keterangan": "Muara air fote", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.684405000001874, 0.518163333333332 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Bay Roray", "X": 353408.25892, "Y": 57477.30026, "Keterangan": "Air terjun kalifote besar", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.682680000001923, 0.519876666666665 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Havo", "X": 361927.95116, "Y": 52490.04125, "Keterangan": "Air terjun Havo Grid 1772", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.759236666668045, 0.474781666666666 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Havo", "X": 362186.75267000002, "Y": 52685.49492, "Keterangan": "Puncak air terjun Havo", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.76156166666803, 0.47655 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Havo", "X": 362031.22229000001, "Y": 53240.33067, "Keterangan": "Air terjun s. Danau sugili", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.760163333334731, 0.481568333333332 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 356802.99902, "Y": 54029.32742, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.713187113405937, 0.488696051761507 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 357100.72564999998, "Y": 53398.46062, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.7158632036315, 0.482990364544092 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 357955.78697999998, "Y": 53473.52312, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.723545636983346, 0.483670765534042 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358797.36002000002, "Y": 53520.52876, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.731106951834334, 0.484097362495958 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358736.99789, "Y": 53549.31816, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.730564558880104, 0.48435766249895 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358721.6145, "Y": 53549.43224, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.730426341296791, 0.48435866832733 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358721.6145, "Y": 53549.43224, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.730426341296791, 0.48435866832733 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358598.57926000003, "Y": 53571.30184, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.729320852087497, 0.484556271694599 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 358517.56858000002, "Y": 53531.30289, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.728593051435112, 0.484194341115652 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Ake bakim dan sekitarnya", "X": 357148.36701, "Y": 54513.2653, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.716289339588712, 0.493073877878485 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Bakim desa Woda", "X": 360308.81188, "Y": 48195.16907, "Keterangan": "Air Tejun Pintu Angin", "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.744695570001468, 0.43593138 ] } },
{ "type": "Feature", "properties": { "Objective": "Sungai Bakim desa Woda", "X": 360208.50812000001, "Y": 50912.00356, "Keterangan": null, "Wisata": "Air Terjun" }, "geometry": { "type": "Point", "coordinates": [ 127.743790170001475, 0.46050532 ] } }
]
}
